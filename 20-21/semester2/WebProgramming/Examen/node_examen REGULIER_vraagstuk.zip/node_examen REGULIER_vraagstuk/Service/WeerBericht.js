class WeerBericht{

    constructor(temperatuur, omschrijving){
        this.temperatuur    = temperatuur
        this.omschrijving   = omschrijving
    }
}

module.exports = WeerBericht